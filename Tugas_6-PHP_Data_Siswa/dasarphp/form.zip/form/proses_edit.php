<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $alamat = $_POST['alamat'];

    $query = "UPDATE siswa SET nama='$nama',email='$email',alamat='$alamat' where id=$id";
    if ($koneksi->query($query) === TRUE) {
        echo "Data berhasil diperbaharui";
        echo "<br><a href='index.php'>Kembali ke Data Siswa</a>";
    } else {
        echo "Error: ".$query."<br>".$koneksi->error;
    }
}
?>