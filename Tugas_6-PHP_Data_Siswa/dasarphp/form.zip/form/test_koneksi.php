<?php
include 'koneksi.php';
echo "Koneksi berhasil";
?>